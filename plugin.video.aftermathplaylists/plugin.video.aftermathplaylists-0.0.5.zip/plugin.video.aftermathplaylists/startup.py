import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathplaylists'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Playlist[/COLOR][/B]'
VERSION        = '0.0.5'
PLAYLIST       = ADDON.getSetting('playlist')
ADULT          = ADDON.getSetting('showadult')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME, 'addons')
USERDATA       = os.path.join(HOME, 'userdata')
REPO           = os.path.join(ADDONS, 'repository.aftermath')
PLUGIN         = os.path.join(ADDONS, ADDON_ID)
PACKAGES       = os.path.join(ADDONS, 'packages')
LISTDIR        = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(PLUGIN, 'fanart.jpg')
ICON           = os.path.join(PLUGIN, 'icon.png')
ART            = os.path.join(PLUGIN, 'resources', 'art')
LIST           = os.path.join(LISTDIR,'favourites.xml')
MODURL         = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
BASEURL        = 'http://cb.srfx.in/playlist/'
AFTERMATH      = 'http://cb.srfx.in/aftermath.xml'
TODAY          = datetime.date.today()

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def LogNotify(title,message,times=2000,icon=ICON):
	xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % (title , message , times, icon))

def checkUpdate():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<addon><name>Aftermath Playlist</name><version>(.+?)</version></addon>').findall(link)
	if match[0] > PLAYLIST or not os.path.exists(LISTDIR):
		redoList()
		
def redoList():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<addon><name>Aftermath Playlist</name><version>(.+?)</version></addon>').findall(link)
	if os.path.exists(LISTDIR): 
		shutil.rmtree(LISTDIR,ignore_errors=True, onerror=None)
		os.makedirs(LISTDIR)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	ADDON.setSetting('showadult', ADULT)
	ADDON.setSetting('playlist', match[0])
	ADDON.setSetting('updated', str(TODAY))
	url = '%splaylist.zip' % BASEURL
	DP.create(ADDONTITLE, 'Downloading updated list!' , '', 'Please Wait')
	lib=os.path.join(PACKAGES, 'playlist.zip')
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	xbmc.sleep(200)
	DP.update(0,'Updating Aftermath Playlist', '', 'Please Wait')
	ext=extract.all(lib,LISTDIR, DP)
	if not ext == True:
		print "ERROR UPDATING LIST"
		LogNotify(ADDONTITLE,'Playlist: [COLOR green]Failed[/COLOR]')
	DP.close()
	LogNotify(ADDONTITLE,'Playlist: [COLOR green]Updated[/COLOR]')
	xbmc.executebuiltin('Container.Refresh()')
	
checkUpdate()