import zipfile

def all(_in, _out, dp=None):
	if dp: return allWithProgress(_in, _out, dp)
	else: return allNoProgress(_in, _out)

def allNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return str(e)
    return True

def allWithProgress(_in, _out, dp):
    try:
        zin = zipfile.ZipFile(_in,  'r')
        nFiles = float(len(zin.namelist()))
        count  = 0
        for item in zin.infolist():
            count += 1
            update = int(count / nFiles * 100)
            dp.update(update, '' ,'Extracting: [COLOR yellow]'+str(item.filename)+'[/COLOR]')
            try:
                zin.extract(item, _out)
            except Exception, e:
                print 'AFTERMATH FAIL: '+str(e)+' / '+item.filename
    except Exception, e:
        print str(e)
        return str(e)
    return True